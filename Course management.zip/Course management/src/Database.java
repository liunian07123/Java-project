import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Database {

    public static final String USERNAME = "root"; 
    public static final String PASSWORD = "root"; 

   public static final String URL = "jdbc:mysql://localhost:3306/coursedb?serverTimezone=UTC";
    private Connection connection;

    public Database() throws SQLException {
       connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public void addCourse(Course course) {
        try {
           
            String sql = "insert into course(code,name,time,room,assistant) values(?,?,?,?,?)";

            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, course.getCode()); 
            stmt.setString(2, course.getName()); 
            stmt.setString(3, course.getTime());
            stmt.setString(4, course.getRoom());
            stmt.setString(5, course.getAssistant());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Course Added."); 
            } catch (SQLException e) { 
            JOptionPane.showMessageDialog(null, "Error, " + e.getMessage());
        }
    }

    public ArrayList<Course> searchCourse(String key) {
       ArrayList<Course> list = new ArrayList<Course>();
           try {
            Statement stmt = connection.createStatement();
            String sql = "select * from course where " + "code like" + "'%" + key + "%'" + "or name like" + "'%" + key
                    + "%'" + "or room like" + "'%" + key + "%'" + "or time like" + "'%" + key + "%'"
                    + "or assistant like" + "'%" + key + "%'";

           if (key.isEmpty()) {
               sql = "select * from course";
            }

           ResultSet rs = stmt.executeQuery(sql);

           while (rs.next()) { 
                String code = rs.getString("code"); 
                String name = rs.getString("name"); 
                String time = rs.getString("time"); 
                String room = rs.getString("room"); 
                String assistant = rs.getString("assistant"); 

                Course course = new Course(code, name, time, room, assistant);
                list.add(course);
            }
        } catch (SQLException e) {
           JOptionPane.showMessageDialog(null, "Error, " + e.getMessage());
        }

        return list;
    }
}
