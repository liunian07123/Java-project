public class Course {

    private String code;
    private String name;
    private String time;
    private String room;
    private String assistant;

   
    public String toString() {
        return "Code: " + code + ", Name: " + name + ", Time: " + time + ", Room: " + room + ", Assistant: "
                + assistant;
    }

    
    public Course(String code, String name, String time, String room, String assistant) {
        this.code = code;
        this.name = name;
        this.time = time;
        this.room = room;
        this.assistant = assistant;
    }

    
    public String getCode() {
        return code;
    }

    
    public void setCode(String code) {
        this.code = code;
    }

    
    public String getName() {
        return name;
    }

   
    public void setName(String name) {
        this.name = name;
    }

    
    public String getTime() {
        return time;
    }

    
    public void setTime(String time) {
        this.time = time;
    }

    
    public String getRoom() {
        return room;
    }

    
    public void setRoom(String room) {
        this.room = room;
    }

    
    public String getAssistant() {
        return assistant;
    }

    public void setAssistant(String assistant) {
        this.assistant = assistant;
    }

}
