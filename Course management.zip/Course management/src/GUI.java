import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GUI extends JFrame {

   private JTextField tfCode, tfName, tfTime, tfRoom, tfAssistant;
    private JButton btnAdd; 

    private JTextField tfKey;
    private JButton btnSearch; 

   private Database database;
   private List<Course> searchResult = new ArrayList<Course>();

   private int current = -1;

   private JTextField tfCodeResult, tfNameResult, tfTimeResult, tfRoomResult, tfAssistantResult;

    private JButton btnFirst, btnLast, btnPrev, btnNext;

   public GUI() {
        try {
           database = new Database();
        } catch (SQLException e) { 
            JOptionPane.showMessageDialog(null, "failed to connect database, " + e.getMessage());
         System.exit(0);
        }
        setTitle("Course Management System"); 

       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        tfCode = new JTextField(15); 
        tfName = new JTextField(15);
        tfTime = new JTextField(15);
        tfRoom = new JTextField(15);
        tfAssistant = new JTextField(15);

       tfKey = new JTextField(20);

       btnSearch = new JButton("Search");
        btnAdd = new JButton("Add");

        tfCodeResult = new JTextField(15);
        tfNameResult = new JTextField(15);
        tfTimeResult = new JTextField(15);
        tfRoomResult = new JTextField(15);
        tfAssistantResult = new JTextField(15);

        btnFirst = new JButton("First");
        btnLast = new JButton("Last");
        btnPrev = new JButton("Previous");
        btnNext = new JButton("Next");

        JPanel inputPanel = new JPanel(new GridLayout(5, 2)); 

        inputPanel.add(new JLabel("Course Code:"));
        inputPanel.add(tfCode);
        inputPanel.add(new JLabel("Course Name:"));
        inputPanel.add(tfName);
        inputPanel.add(new JLabel("Course Time:"));
        inputPanel.add(tfTime);
        inputPanel.add(new JLabel("Course Room:"));
        inputPanel.add(tfRoom);
        inputPanel.add(new JLabel("Assistant:"));
        inputPanel.add(tfAssistant);

       JPanel leftPanel = new JPanel(new BorderLayout());
       leftPanel.add(inputPanel);
        JPanel buttnWrapperPanel = new JPanel();
       buttnWrapperPanel.add(btnAdd);
       leftPanel.add(buttnWrapperPanel, BorderLayout.SOUTH);
       JPanel leftPanelWrappter = new JPanel(); 
       leftPanelWrappter.add(leftPanel); 

        JPanel viewPanel = new JPanel(new GridLayout(5, 2)); 

        viewPanel.add(new JLabel("Course Code:"));
        viewPanel.add(tfCodeResult);
        viewPanel.add(new JLabel("Course Name:"));
        viewPanel.add(tfNameResult);
        viewPanel.add(new JLabel("Course Time:"));
        viewPanel.add(tfTimeResult);
        viewPanel.add(new JLabel("Course Room:"));
        viewPanel.add(tfRoomResult);
        viewPanel.add(new JLabel("Assistant:"));
        viewPanel.add(tfAssistantResult);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(viewPanel, BorderLayout.CENTER);
        JPanel naviPanel = new JPanel();
        naviPanel.add(btnFirst);
        naviPanel.add(btnPrev);
        naviPanel.add(btnNext);
        naviPanel.add(btnLast);

        JPanel searchPanel = new JPanel();
        searchPanel.add(tfKey);
        searchPanel.add(btnSearch);
        rightPanel.add(searchPanel, BorderLayout.NORTH);
        rightPanel.add(naviPanel, BorderLayout.SOUTH);

        JPanel rightPanelWrappter = new JPanel(); 
        rightPanelWrappter.add(rightPanel); 

       JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(leftPanelWrappter, BorderLayout.WEST); 
        mainPanel.add(rightPanelWrappter, BorderLayout.CENTER); 

       setContentPane(mainPanel);

       btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { 
               doAdd(); 
            }
        });

       btnSearch.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
                doSearch();
            }
        });

       btnFirst.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doFirst(); 
            }
        });

      btnLast.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doLast(); 
            }
        });

        btnPrev.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doPrev(); 
            }
        });

        btnNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doNext(); 
            }
        });

       pack();
       setLocationRelativeTo(null);
    }

   public void doAdd() {
        String code = tfCode.getText();
        String name = tfName.getText();
        String time = tfTime.getText();
        String room = tfRoom.getText();
        String assistant = tfAssistant.getText();

        if (code.isEmpty()) {
            JOptionPane.showMessageDialog(this, "code is empty");
            return;
        }

        if (name.isEmpty()) {
             JOptionPane.showMessageDialog(this, "name is empty");
            return;
        }

        if (time.isEmpty()) {
             JOptionPane.showMessageDialog(this, "time is empty");
            return;
        }

        if (room.isEmpty()) {
             JOptionPane.showMessageDialog(this, "room is empty");
            return;
        }

        if (assistant.isEmpty()) {
            JOptionPane.showMessageDialog(this, "assistant is empty");
            return;
        }

       Course course = new Course(code, name, time, room, assistant);
       database.addCourse(course);
    }
       public void doSearch() {
       String code = tfKey.getText();

        ArrayList<Course> courses = database.searchCourse(code);

       searchResult.clear(); 
       searchResult.addAll(courses); 

       if (searchResult.size() > 0) {
            current = 0; 

           viewCourse(searchResult.get(current));
        } else {
           tfCodeResult.setText("");
            tfNameResult.setText("");
            tfTimeResult.setText("");
            tfRoomResult.setText("");
            tfAssistantResult.setText("");
        }
    }

     private void viewCourse(Course course) {
        tfCodeResult.setText(course.getCode()); 
        tfNameResult.setText(course.getName());
        tfTimeResult.setText(course.getTime());
        tfRoomResult.setText(course.getRoom());
        tfAssistantResult.setText(course.getAssistant());
    }

    public void doNext() {
        
        if (current < searchResult.size() - 1) {
            current++; 
          viewCourse(searchResult.get(current));
        } else {
        JOptionPane.showMessageDialog(this, "no next record");
     
    }
    }
   
    public void doPrev() {
        
        if (current > 0) {
            current--; 

            viewCourse(searchResult.get(current));
        } else {

            JOptionPane.showMessageDialog(this, "no previous record");
        }
    }

     public void doLast() {
         if (searchResult.size() > 0) {
            current = searchResult.size() - 1; 
            viewCourse(searchResult.get(current));
        } else {
        JOptionPane.showMessageDialog(this, "result is empty");
        }
    }

   public void doFirst() {
       
        if (searchResult.size() > 0) {
            current = 0; 

           viewCourse(searchResult.get(current));
        } else {

            JOptionPane.showMessageDialog(this, "result is empty");
        }
    }
}
